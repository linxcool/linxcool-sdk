package com.linxcool.security;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class PluginMaker {

	private static final int LENGTH_COMMENT = 200;
	private static final char CHARACTER_NULL = '*';
	private static final int BUFFER_SIZE = 4096;
	
	/**
	 * 对插件签名打版本
	 * @param filePath 目标文件
	 * @param key 签名秘钥
	 * @param name 插件名
	 * @param ver 插件版本
	 */
	public static boolean signedPluginJar(
			String filePath, String name, String ver,String cls, String target){
		try {
			ZipFile zipFile = new ZipFile(filePath);
			
			String comment = String.format(
					Locale.getDefault(), 
					"%s|%s|%s",
					name, 
					ver,
					cls);
			comment = SecurityUtil.mixEncrypt(comment);
			StringBuilder sb = new StringBuilder(comment);
			while(sb.length() < LENGTH_COMMENT)
				sb.append(CHARACTER_NULL);
			comment = sb.toString();
			
			ZipOutputStream zos=new ZipOutputStream(new FileOutputStream(target)); 
			zos.setComment(comment);
			
			byte[] buf=new byte[BUFFER_SIZE];
			Enumeration<? extends ZipEntry> entries = zipFile.entries();
			while(entries.hasMoreElements()){
				ZipEntry entry = entries.nextElement();
				zos.putNextEntry(entry);  
				InputStream is = zipFile.getInputStream(entry);
				int len = -1;
				while((len = is.read(buf)) != -1){
					zos.write(buf, 0, len);
				}
			}

			zos.flush();
			zos.close();
			zipFile.close();

			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	protected static String encodeValue(String key, String value){
		StringBuilder kb = new StringBuilder(key);
		int vLen = value.length();
		while(vLen > kb.length()){
			kb.append(key);
		}

		char[] ks = kb.toString().toCharArray();
		char[] vs = value.toCharArray();
		for (int i = 0; i < vLen; i++) {
			vs[i] = (char) (vs[i]^ks[i]);
		}
		return SecurityUtil.bytesToHexString(new String(vs).getBytes());
	}

	protected static String decodeValue(String key, String value){
		StringBuilder kb = new StringBuilder(key);
		value = new String(SecurityUtil.hexStringToBytes(value));
		int vLen = value.length();
		while(vLen > kb.length()){
			kb.append(key);
		}

		char[] ks = kb.toString().toCharArray();
		char[] vs = value.toCharArray();
		for (int i = 0; i < vLen; i++) {
			vs[i] = (char) (vs[i]^ks[i]);
		}

		return new String(vs);
	}

	public static boolean verify(String filePath){
		try {
			return verify(new DataInputStream(new FileInputStream(filePath)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static boolean signedPlugin(
			String filePath, String name, String ver,String cls, String target){
		try {
			String comment = String.format(
					Locale.getDefault(), 
					"%s|%s|%s",
					name, 
					ver,
					cls);
			comment = SecurityUtil.mixEncrypt(comment);
			StringBuilder sb = new StringBuilder(comment);
			while(sb.length() < LENGTH_COMMENT)
				sb.append(CHARACTER_NULL);
			comment = sb.toString();
			
			System.out.println(comment);
			
			FileInputStream fis = new FileInputStream(filePath);
			DataOutputStream dos = new DataOutputStream(new FileOutputStream(target));
			byte[] buf = new byte[1024];
			int len;
			while ((len = fis.read(buf)) > 0) {
				dos.write(buf, 0, len);
			}
			
			dos.write(comment.getBytes());
			
			fis.close();
			dos.flush();
			dos.close();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static boolean verify(DataInputStream dis){
		try{
			dis.skip(dis.available() - LENGTH_COMMENT);
			byte[] buffer = new byte[LENGTH_COMMENT];
			dis.read(buffer);
			dis.close();
			
			String comment = new String(buffer);
			System.out.println(comment);
			if(comment == null || comment.length() == 0)
				return false;
			
			comment = comment.replace("*", "");
			comment = SecurityUtil.mixDecrypt(comment);
			System.out.println(comment);
			
			String[] data = comment.split("\\|");
			if(data.length < 3)
				return false;
			
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}

	public static void main(String[] args) {
		try {
			
			if(args == null || args.length != 5){
				System.out.println("参数错误！");
				return;
			}
			
			String filePath = args[0];
			String name = args[1];
			String version = args[2];
			String apiCls = args[3];
			String outPath = args[4];
			
			/*String filePath = "F:/pluginMaker/kernelSdk_dex.jar";
			String name = "kernelSdk";
			String version = "1";
			String apiCls = "com.linxcool.sdk.entry.KernelSdk";
			String outPath = "F:/pluginMaker/kernelSdk.jar";*/
			
			System.out.println("开始执行签名....");
			
			if(signedPlugin(filePath, name, version, apiCls, outPath)){
			//if(signedPluginJar(filePath, name, version, apiCls, outPath)){
				System.out.println("签名成功！");
			} else {
				System.out.println("签名失败！");
			}
			
			//verify(outPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
