package com.linxcool.security;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularMatcher {
	
	public static String getIp(String input){
		String regex = "((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(input);
		if (m.find()) {
			return m.group();
		}
		return null;
	}

	public static String getSubject(String input){
		String regex = "\\d+ packets transmitted, \\d+ received, \\d+% packet loss, time .*?ms";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(input);
		if (m.find()) {
			String temp = m.group();
			System.out.println(temp);

			String result = "";

			Matcher total = Pattern.compile("\\d+(?= packets)").matcher(temp);
			total.find();
			result += total.group();

			Matcher received = Pattern.compile("\\d+(?= received)").matcher(temp);
			received.find();
			result += " " + received.group();

			Matcher loss = Pattern.compile("\\d+(?=% packet)").matcher(temp);
			loss.find();
			result += " " + loss.group();

			System.out.println(result);

			return result;
		}
		return null;
	}

	public static String getRecords(String input){
		String regex = "\\d+ bytes from .*?ms";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(input);
		String result = "";

		while (m.find()) {
			String temp = m.group();
			System.out.println(temp);

			Matcher bytes = Pattern.compile("\\d+(?= bytes from)").matcher(temp);
			bytes.find();
			result += " " + bytes.group();

			Matcher time = Pattern.compile("(?<=time=).+(?= ms)").matcher(temp);
			time.find();
			result += " " + time.group();
		}
		
		if(result.length() == 0)
			return null;
		
		return result.substring(1);
	}

	public static String getTimes(String input){
		Matcher time = Pattern.compile("(?<=min/avg/max/mdev = ).+(?= ms)").matcher(input);
		time.find();
		return time.group();
	}
}
